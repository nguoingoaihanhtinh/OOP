#pragma once
#include<iostream>
using namespace std;
class Gate
{
private:
	int tien, ttue, smanh;
	int loai;
public:
	virtual void Nhap() = 0;
	virtual int Xuat() = 0;
	int getType()
	{
		return loai;
	}

	virtual bool Check(int& tien, int ttue, int& smanh) = 0;

};

