#pragma once
#include "Gate.h"
class AcademicGate :
    public Gate
{
private:
	int dokho;
public:
	void Nhap()
	{

		cout << "Nhap tri tue cau hoi "; cin >> dokho;
	}
	int Xuat()
	{
		return dokho;
	}

	bool Check(int& tien, int ttue, int& smanh)
	{
		if (ttue > dokho)
		{
			return 1;
		}
		return 0;

	}
};

