#pragma once
#include "Gate.h"
class PowerGate :
    public Gate
{
private:
	int dungsi;
public:
	void Nhap()
	{

		cout << "Nhap suc manh dung si "; cin >> dungsi;
	}
	int Xuat()
	{
		return dungsi;
	}
	bool Check(int& tien, int ttue, int& smanh)
	{
		if (smanh > dungsi)
		{
			smanh -= dungsi;
			return 1;
		}
		return 0;
	}

};

