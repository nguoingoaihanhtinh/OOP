#pragma once
#include "Gate.h"


class BusinessGate :
    public Gate
{
private:
	int dongia, sluong;
public:
	void Nhap()
	{

		cout << "Nhap don gia , so hang";
		cin >> dongia >> sluong;
	}
	int Xuat()
	{
		return dongia * sluong;
	}

	bool Check(int& tien, int ttue, int& smanh)
	{
		if (tien > dongia * sluong)
		{

			tien -= dongia * sluong;
			return 1;
		}
		return 0;
	}
};

