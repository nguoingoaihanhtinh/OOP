#include "BusinessGate.h"
#include "AcademicGate.h"
#include "PowerGate.h"

int main()
{
	cout << "Nhap so cong: ";
	int n; cin >> n;
	cout << "\n1.Cong giao thuong";
	cout << "\n2.Cong hoc thuat";
	cout << "\n3.Cong suc manh";
	Gate* a[1000];
	for (int i = 0; i < n; i++)
	{
		cout << "\nNhap vao loai cong";
		int l; cin >> l;
		if (l == 1) a[i] = new BusinessGate();
		if (l == 2) a[i] = new AcademicGate();
		if (l == 3) a[i] = new PowerGate();
		a[i]->Nhap();
		a[i]->Xuat();
	}

	cout << "\nNhap chi so Hoang Tu ";
	cout << "\nNhap so tien ";
	int tien; cin >> tien;
	cout << "\nNhap chi so tri tue";
	int ttue; cin >> ttue;
	cout << "\nNhap chi so suc manh";
	int smanh; cin >> smanh;
	for (int i = 0; i < n; i++)
	{
		if (a[i]->Check(tien, ttue, smanh))
		{
		}
		else {
			cout << "Khong cuu duoc";
			return 0;
		}
	}
	cout << "Cuu duoc cong chua" << endl;
	cout << "Tien te: " << tien << endl;
	cout << "Tri tue: " << ttue << endl;
	cout << "Suc manh: " << smanh << endl;
}