#include "MangNguoi.h"
using namespace std;
int main()
{
	MangNguoi a;
	a.Nhap();
	a.Xuat();
	cout << endl << endl;

	a.Nguyco();

}